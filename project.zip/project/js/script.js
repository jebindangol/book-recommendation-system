let userBox = document.querySelector('.header .header-2 .user-box');

document.querySelector('#user-btn').onclick = () =>{
   userBox.classList.toggle('active');
   navbar.classList.remove('active');
}

let navbar = document.querySelector('.header .header-2 .navbar');

document.querySelector('#menu-btn').onclick = () =>{
   navbar.classList.toggle('active');
   userBox.classList.remove('active');
}

window.onscroll = () =>{
   userBox.classList.remove('active');
   navbar.classList.remove('active');

   if(window.scrollY > 60){
      document.querySelector('.header .header-2').classList.add('active');
   }else{
      document.querySelector('.header .header-2').classList.remove('active');
   }
}
// collbrative
document.addEventListener("DOMContentLoaded", function() {
   // Fetch recommended books data from the server
   fetch("fetch_recommended_books.php") // Replace with the actual URL to your PHP script
       .then(response => response.json())
       .then(data => displayRecommendedBooks(data))
       .catch(error => console.error("Error fetching recommended books:", error));
});

function displayRecommendedBooks(books) {
   const recommendedBooksContainer = document.getElementById("recommended-books");

   if (books.length === 0) {
       recommendedBooksContainer.innerHTML = "<p>No recommendations available.</p>";
       return;
   }

   const bookList = books.map(book => `
       <div class="book">
           <img src="uploaded_img/${book.image}" alt="${book.name}">
           <h2>${book.name}</h2>
           <p>Category: ${book.category}</p>
           <p>Price: Rs.${book.price}/-</p>
       </div>
   `).join("");

   recommendedBooksContainer.innerHTML = bookList;
}
// ----collabrative

