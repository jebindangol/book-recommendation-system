<?php
function getUserInteractions($book_id) {
    // This function doesn't need to include 'config.php' again since it's already included in the main script

    $user_interactions = array(); // Initialize an array to store user interactions
    
    // Query your database to fetch user interactions for the given book_id
    $query = "SELECT user_id FROM user_interactions WHERE book_id = '$book_id'";
    $result = mysqli_query($conn, $query);
    
    // Loop through the result and populate the user_interactions array
    while ($row = mysqli_fetch_assoc($result)) {
        $user_interactions[] = $row['user_id'];
    }
    
    return $user_interactions; // Return the array of user interactions
}
?>
