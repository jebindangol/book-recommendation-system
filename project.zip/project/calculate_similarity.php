<?php

// Database connection setup
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "shop_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user interactions from the database
$query = "SELECT user_id, book_id, rating FROM user_interactions";
$result = $conn->query($query);

// Organize interaction data into user-category vectors
$userCategoryInteractions = [];
while ($row = $result->fetch_assoc()) {
    $user_id = $row["user_id"];
    $book_id = $row["book_id"];
    $rating = $row["rating"];
    
    // Fetch the book's category from the products table
    $categoryQuery = "SELECT category FROM products WHERE id = $book_id";
    $categoryResult = $conn->query($categoryQuery);
    $categoryRow = $categoryResult->fetch_assoc();
    $category = $categoryRow["category"];
    
    $userCategoryInteractions[$user_id][$category][$book_id] = $rating;
}

// Function to calculate cosine similarity
function cosineSimilarity($vectorA, $vectorB) {
    // Calculate cosine similarity using the algorithm mentioned earlier
    $dotProduct = 0;
    $magnitudeA = 0;
    $magnitudeB = 0;

    foreach ($vectorA as $key => $value) {
        if (isset($vectorB[$key])) {
            $dotProduct += $value * $vectorB[$key];
        }
        $magnitudeA += $value * $value;
    }

    foreach ($vectorB as $value) {
        $magnitudeB += $value * $value;
    }

    $magnitudeA = sqrt($magnitudeA);
    $magnitudeB = sqrt($magnitudeB);

    if ($magnitudeA == 0 || $magnitudeB == 0) {
        return 0; // To avoid division by zero
    } else {
        return $dotProduct / ($magnitudeA * $magnitudeB);
    }
}

// Calculate cosine similarity between users based on category
$userId1 = 1;
$userId2 = 2;
$category = "Fiction"; // Replace with the desired category

if (isset($userCategoryInteractions[$userId1][$category]) && isset($userCategoryInteractions[$userId2][$category])) {
    $userVector1 = $userCategoryInteractions[$userId1][$category];
    $userVector2 = $userCategoryInteractions[$userId2][$category];
    
    $similarity = cosineSimilarity($userVector1, $userVector2);
    echo "Cosine Similarity for Category $category between User $userId1 and User $userId2: $similarity";
} else {
    echo "One or both users don't have interaction data for the specified category.";
}

// Close the database connection
$conn->close();

?>
